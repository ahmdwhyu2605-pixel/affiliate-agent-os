# Affiliate Agent OS — Starter V1

Dashboard PWA berbahasa Indonesia untuk workflow Shopee Affiliate. Dibuat sebagai fondasi yang bisa dibuka di HP Android, tanpa framework dan tanpa biaya hosting jika memakai GitHub Pages.

## Yang sudah berfungsi
- Dashboard responsif dengan tema gelap, robot 3D-style CSS, dan visual jalur workflow.
- Simpan kandidat produk, harga, komisi, link, dan angle promosi ke localStorage.
- Buat draft skrip berbasis template (belum AI generatif).
- Jadwal publikasi/pengingat lokal (belum mengunggah konten).
- Catat views, klik, dan komisi secara manual.
- Ekspor CSV dan backup JSON.
- PWA dasar/offline cache.

## Batas penting
Ini belum full autopilot dan belum tersambung ke akun Shopee, API model AI, atau akun media sosial. Jangan menganggap komisi/produk otomatis terbaca. Jangan simpan password, token, atau secret key di frontend. Integrasi perlu backend/Edge Functions dan akses API resmi yang benar-benar tersedia; jangan memakai scraping atau bot yang melanggar ketentuan platform.

## Pasang melalui GitHub Pages dari Android
1. Ekstrak ZIP ini di HP.
2. Buka repositori GitHub yang akan dipakai, misalnya buat repo baru `affiliate-agent-os`.
3. Upload lima file di root: `index.html`, `style.css`, `app.js`, `manifest.webmanifest`, `sw.js`, plus `README.md`.
4. Di repo buka **Settings → Pages**, pilih **Deploy from a branch**, branch `main`, folder `/(root)`, lalu Save.
5. Tunggu deployment selesai, buka URL Pages yang muncul.
6. Di Chrome Android pilih menu ⋮ → **Tambahkan ke layar utama**.
7. Data starter disimpan di browser/perangkat. Ekspor backup rutin; data tidak otomatis tersinkron antarperangkat.

## Tahap berikutnya untuk mendekati autopilot
1. Supabase Auth + database multi-user (jangan letakkan service-role key di browser).
2. Backend/Edge Function untuk panggilan AI dengan secret tersimpan aman.
3. Pipeline: riset → validasi produk → ide → skrip → review → antrean.
4. Integrasi data/tautan affiliate melalui fitur resmi yang tersedia pada akun/region pengguna.
5. Publikasi otomatis hanya jika API resmi platform mengizinkan; jika tidak, buat paket siap-posting dan pengingat.
6. Log aktivitas, batas biaya, persetujuan manusia, dan monitoring error.

## Cara pakai
- Riset Produk: masukkan produk yang sudah ditemukan dari sumber resmi.
- Studio Konten: buat draft template dan salin.
- Jadwal: masukkan tanggal/waktu publikasi.
- Analitik: catat data performa yang terlihat pada platform.
