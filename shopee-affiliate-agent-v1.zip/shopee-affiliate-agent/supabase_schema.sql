-- Tahap backend berikutnya. Jalankan hanya pada proyek Supabase baru/yang sudah dicadangkan.
-- RLS membatasi setiap user pada data miliknya. Jangan menaruh service_role key di frontend.
create extension if not exists pgcrypto;

create table if not exists public.affiliate_products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  product_url text,
  price numeric(14,2) not null default 0,
  commission_rate numeric(5,2) not null default 0,
  promo_angle text,
  created_at timestamptz not null default now()
);
create table if not exists public.content_drafts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_name text not null,
  platform text not null default 'TikTok',
  style text,
  duration_seconds integer,
  script text not null default '',
  status text not null default 'draft',
  created_at timestamptz not null default now()
);
create table if not exists public.publish_schedule (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  platform text not null,
  publish_at timestamptz not null,
  status text not null default 'queued',
  created_at timestamptz not null default now()
);
create table if not exists public.performance_metrics (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  content_name text not null,
  views bigint not null default 0,
  clicks bigint not null default 0,
  commission numeric(14,2) not null default 0,
  recorded_at timestamptz not null default now()
);

alter table public.affiliate_products enable row level security;
alter table public.content_drafts enable row level security;
alter table public.publish_schedule enable row level security;
alter table public.performance_metrics enable row level security;

create policy "own affiliate products" on public.affiliate_products
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own content drafts" on public.content_drafts
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own publish schedule" on public.publish_schedule
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own performance metrics" on public.performance_metrics
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
